from django.contrib import admin

from . import models

class SecurityAdmin(admin.ModelAdmin):
    pass

admin.site.register(models.Security, SecurityAdmin)