from django.urls import path

from .import views

urlpatterns = [
    path('menuplanner', views.MenusListView.as_view()),
    path('menuplanner/<int:pk>', views.detail),
]