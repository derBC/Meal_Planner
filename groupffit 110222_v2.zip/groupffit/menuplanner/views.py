from django.shortcuts import render
from django.http import Http404
from django.views.generic import ListView

from .models import Menus

class MenusListView(ListView):
    model = Menus
    context_object_name = "menus"

def detail(request, pk):
    try:
        menu = Menus.objects.get(pk=pk)
    except Menus.DoesNotExist:
        raise Http404("Menu doesn't exist")
    return render(request, 'menuplanner/menu_detail.html', {'menu': menu})