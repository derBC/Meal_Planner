from django.shortcuts import render

from .models import Menus

def list(request):
    all_menus = Menus.objects.all()
    return render(request, 'menuplanner/menu_list.html', {'menuplanner: all_menus'})
