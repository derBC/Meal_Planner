from django.contrib import admin

from . import models

class MenusAdmin(admin.ModelAdmin):
    list_display = ('title',)

admin.site.register(models.Menus, MenusAdmin)