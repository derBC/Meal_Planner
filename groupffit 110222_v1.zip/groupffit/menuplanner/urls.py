from django.urls import path

from . import views

urlpatterns = [
    path('menuplanner', views.list),
    path('menuplanner', views.menuwel),
]